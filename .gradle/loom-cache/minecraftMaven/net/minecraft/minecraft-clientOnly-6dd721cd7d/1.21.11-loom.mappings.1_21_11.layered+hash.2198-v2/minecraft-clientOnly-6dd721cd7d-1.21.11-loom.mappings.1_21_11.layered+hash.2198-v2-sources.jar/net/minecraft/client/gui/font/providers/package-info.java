@NullMarked
@Environment(EnvType.CLIENT)
package net.minecraft.client.gui.font.providers;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
