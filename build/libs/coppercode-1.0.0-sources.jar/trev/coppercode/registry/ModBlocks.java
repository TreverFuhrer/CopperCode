package trev.coppercode.registry;

import java.util.function.Function;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import trev.coppercode.util.ModIds;

/** Owns block registrations and shared block registration helpers. */
public final class ModBlocks {
	private ModBlocks() {
	}

	public static void initialize() {
		registerBlocks();
	}

	private static void registerBlocks() {
		// TODO Register mod blocks here.
		// TODO Register matching BlockItem entries in ModItems when blocks are introduced.
	}

	public static class_2248 register(String path, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 properties) {
		return class_2378.method_10230(class_7923.field_41175, ModIds.id(path), factory.apply(properties));
	}
}
