package trev.coppercode.registry;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import trev.coppercode.util.ModIds;

/** Owns sound event registrations and a helper for future custom sounds. */
public final class ModSoundEvents {
	private ModSoundEvents() {
	}

	public static void initialize() {
		registerSoundEvents();
	}

	private static void registerSoundEvents() {
		// TODO Register custom sound events here.
	}

	public static class_3414 register(String path) {
		class_2960 id = ModIds.id(path);
		return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
	}
}
