package trev.coppercode.registry;

import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import trev.coppercode.util.ModIds;

/** Owns item registrations and shared item registration helpers. */
public final class ModItems {
	private ModItems() {
	}

	public static void initialize() {
		registerItems();
	}

	private static void registerItems() {
		// TODO Register mod items here.
	}

	public static class_1792 register(String path, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 properties) {
		return class_2378.method_10230(class_7923.field_41178, ModIds.id(path), factory.apply(properties));
	}
}
