package trev.coppercode.util;

import net.minecraft.class_2960;

/** Small helper for creating identifiers inside the Copper Code namespace. */
public final class ModIds {
	private ModIds() {
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(ModConstants.MOD_ID, path);
	}
}
