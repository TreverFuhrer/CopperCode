package trev.coppercode.datagen;

import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import trev.coppercode.util.ModConstants;

/** Generates the base English translations for Copper Code. */
public final class ModEnglishLangProvider extends FabricLanguageProvider {
	public ModEnglishLangProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
		super(dataOutput, registryLookup);
	}

	@Override
	public void generateTranslations(class_7225.class_7874 registryLookup, TranslationBuilder translationBuilder) {
		translationBuilder.add("itemGroup.coppercode.main", ModConstants.MOD_NAME);

		// TODO Add item, block, entity, screen, and message translations here as content is introduced.
	}
}
