package trev.coppercode.datagen;

import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;

/** Generates item tags for Copper Code items and block items. */
public final class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
	public ModItemTagProvider(
		FabricDataOutput output,
		CompletableFuture<class_7225.class_7874> registriesFuture,
		ModBlockTagProvider blockTagProvider
	) {
		super(output, registriesFuture, blockTagProvider);
	}

	@Override
	protected void method_10514(class_7225.class_7874 wrapperLookup) {
		// TODO Copy relevant block tags and add item-only tags here when content is introduced.
	}
}
