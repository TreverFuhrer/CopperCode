package trev.coppercode.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

/** Generates client asset models for blocks and items. */
public final class ModModelProvider extends FabricModelProvider {
	public ModModelProvider(FabricDataOutput output) {
		super(output);
	}

	@Override
	public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
		// TODO Generate blockstate and block models here when mod blocks are added.
	}

	@Override
	public void generateItemModels(class_4915 itemModelGenerator) {
		// TODO Generate item models here when mod items are added.
	}
}
