package trev.coppercode.datagen;

import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_8790;

/** Generates Copper Code recipe data once craftable content exists. */
public final class ModRecipeProvider extends FabricRecipeProvider {
	public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
		super(output, registriesFuture);
	}

	@Override
	public String method_10321() {
		return "Copper Code Recipes";
	}

	@Override
	protected class_2446 method_62766(class_7225.class_7874 registryLookup, class_8790 exporter) {
		return new class_2446(registryLookup, exporter) {
			@Override
			public void method_10419() {
				// TODO Add recipes here as Copper Code content is introduced.
			}
		};
	}
}
